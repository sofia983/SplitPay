Nombre: SplitPay
Problema:
Las aplicaciones bancarias permiten consultar transacciones individuales, pero no facilitan el seguimiento de gastos compartidos entre varias personas. Esto genera dificultades para mantener un historial claro de los aportes, deudas y obligaciones pendientes, especialmente cuando los gastos se acumulan con el tiempo.
Stakeholders
* Usuarios finales: personas que comparten gastos y necesitan realizar seguimiento de sus aportes y obligaciones.
* Equipo de desarrollo: responsables de dise�ar, desarrollar, probar y documentar el proyecto.
* Docente: responsable de orientar y evaluar el proyecto durante el semestre.
* GitHub: entorno utilizado para almacenar el c�digo y gestionar Issues, ramas, Pull Requests y documentaci�n.
* Firebase: servicios utilizados para autenticaci�n y almacenamiento de informaci�n.
* Proveedor de API: servicio externo utilizado para obtener informaci�n de tasas de cambio.
* Actores
* Usuario: registra y consulta sus gastos compartidos, grupos, aportes y balances.
* Firebase Authentication: gestiona la autenticaci�n de los usuarios.
* Firebase Firestore: almacena los usuarios, grupos, gastos y registros relacionados.
* API de tasas de cambio: proporciona informaci�n para realizar conversiones entre monedas.
* GitHub: permite gestionar el c�digo, las tareas y las contribuciones del equipo.
* Objetivo y metricas de exito


Objetivo
* Desarrollar un MVP m�vil que permita registrar y consultar gastos compartidos, mantener un historial financiero de los grupos y calcular los aportes, saldos y obligaciones de cada integrante a lo largo del tiempo.
* M�tricas de �xito
* Registrar un gasto de forma r�pida y sencilla.
* Mantener un historial organizado de los gastos realizados.
* Mostrar cu�nto ha aportado cada integrante.
* Identificar los saldos pendientes de cada usuario.
* Permitir consultar gastos anteriores por grupo.
* Calcular correctamente la distribuci�n de los gastos.
* Obtener tasas de cambio mediante una API externa.
* Mantener la informaci�n almacenada y disponible para consultas posteriores.
* Mantener el c�digo y las tareas del proyecto organizados en GitHub.
Restricciones
* El proyecto ser� desarrollado con Flutter y Dart.
* El c�digo fuente y la documentaci�n estar�n alojados en GitHub.
* Git ser� utilizado para el control de versiones.
* Las tareas se gestionar�n mediante GitHub Issues.
* Las funcionalidades se desarrollar�n mediante ramas y se integrar�n utilizando Pull Requests.
* Se utilizar� Firebase Authentication para la gesti�n de usuarios.
* Se utilizar� Firebase Firestore como base de datos.
* Se utilizar� una API externa para las tasas de cambio.
* El MVP tendr� tres pantallas principales.
* No se realizar�n transferencias bancarias reales.
* La aplicaci�n no reemplazar� una aplicaci�n bancaria ni llevar� contabilidad profesional.
* El proyecto estar� limitado a las funcionalidades necesarias para el MVP del semestre.

Alcance
Incluye
* Registro e inicio de sesi�n.
* Creaci�n y consulta de grupos.
* Registro de gastos compartidos.
* Identificaci�n del usuario que realiz� cada pago.
* Selecci�n de los participantes de cada gasto.
* C�lculo de la participaci�n de cada integrante.
* Historial de gastos.
* Consulta de aportes realizados a lo largo del tiempo.
* Consulta de balances individuales.
* Identificaci�n de saldos pendientes.
* Conversi�n entre monedas mediante una API.
* Almacenamiento de la informaci�n en Firestore.
* Gesti�n del c�digo, Issues y Pull Requests mediante GitHub.
No incluye
* Transferencias de dinero.
* Integraci�n directa con cuentas bancarias.
* Acceso a movimientos reales de bancos.
* Pagos mediante tarjetas o billeteras digitales.
* Contabilidad empresarial.
* Declaraciones de impuestos.
* Pr�stamos o cr�ditos.
* Inversiones.
* Chat entre usuarios.
* Notificaciones avanzadas.
* Aplicaci�n web o de escritorio.
* Inteligencia artificial.
* Funcionalidades que no est�n relacionadas con el registro, seguimiento e historial de gastos compartidos.
Conceptos del dominio
* Usuario: persona que utiliza la aplicaci�n.
* Grupo: conjunto de personas que comparten gastos.
* Gasto: registro de un pago realizado dentro de un grupo.
* Pagador: integrante que realiz� el pago.
* Participante: integrante que debe asumir una parte del gasto.
* Aporte: cantidad de dinero que un integrante ha pagado.
* Balance: diferencia entre lo que una persona ha aportado y lo que le corresponde asumir.
* Deuda: cantidad pendiente que un integrante debe a otro.
* Historial: registro cronol�gico de los gastos realizados.
* Moneda: unidad monetaria utilizada para registrar un gasto.
* Tasa de cambio: valor obtenido mediante la API para convertir un gasto entre monedas.
Reglas de negocio
* El usuario debe iniciar sesi�n para acceder a sus grupos y gastos.
* Cada gasto debe pertenecer a un grupo.
* Cada gasto debe registrar una descripci�n, valor, moneda, fecha y pagador.
* Cada gasto debe tener al menos un participante.
* El sistema debe calcular la parte correspondiente a cada participante.
* El aporte realizado por cada integrante debe quedar registrado en el historial.
* Los gastos no deben eliminarse del historial sin una acci�n expl�cita del usuario.
* Los balances deben actualizarse cuando se registre un nuevo gasto.
* Un balance positivo representa un valor a favor del usuario.
* Un balance negativo representa un valor pendiente por pagar.
* Los gastos deben conservar su fecha para permitir la trazabilidad a lo largo del tiempo.
* Solo los integrantes de un grupo pueden consultar la informaci�n de ese grupo.
* Las conversiones de moneda utilizar�n informaci�n proporcionada por la API externa.
* La aplicaci�n no realizar� pagos ni transferencias reales.
* Las funcionalidades nuevas del proyecto deber�n registrarse mediante una Issue en GitHub.
* El desarrollo de una funcionalidad deber� realizarse en una rama independiente.
* Los cambios deber�n integrarse a main mediante Pull Request.
Historias de usuario
HU01 � Acceso a la aplicaci�n
* Como usuario,
quiero registrarme e iniciar sesi�n,
para acceder de forma segura a mis registros financieros.
HU02 � Crear grupo
* Como usuario,
quiero crear un grupo con otras personas,
para organizar los gastos que compartimos.
HU03 � Registrar gasto
* Como integrante de un grupo,
quiero registrar un gasto indicando qui�n pag� y qui�nes participaron,
para mantener actualizado el historial financiero del grupo.
HU04 � Consultar historial
* Como usuario,
quiero consultar los gastos realizados anteriormente,
para conocer c�mo se han distribuido los gastos a lo largo del tiempo.
HU05 � Consultar aportes
* Como usuario,
quiero conocer cu�nto ha aportado cada integrante,
para comparar los pagos realizados dentro del grupo.
HU06 � Consultar balance
* Como usuario,
quiero conocer mi balance y mis saldos pendientes,
para saber cu�nto debo pagar o cu�nto debo recibir.
HU07 � Consultar conversi�n
* Como usuario,
quiero convertir el valor de un gasto entre diferentes monedas,
para registrar y comprender gastos realizados en moneda extranjera.

Casos de uso
CU01 � Iniciar sesi�n
* Actor principal: Usuario
Actores secundarios: Firebase Authentication
Precondici�n:
* El usuario debe estar registrado.
* La aplicaci�n debe tener conexi�n a Internet.
* Firebase Authentication debe estar disponible.
Flujo principal:
* El usuario abre la aplicaci�n.
* Ingresa su correo electr�nico y contrase�a.
* El sistema env�a las credenciales a Firebase Authentication.
* Firebase valida las credenciales.
* El sistema permite el acceso.
* El usuario es dirigido a la pantalla de inicio.
* Flujo de excepci�n:
* Si el correo o la contrase�a son incorrectos, el sistema informa que las credenciales no son v�lidas y solicita ingresarlas nuevamente.
* Si no existe conexi�n a Internet, el sistema informa que no puede realizar la autenticaci�n.
* Si ocurre un error en Firebase, el sistema muestra un mensaje de error y permite volver a intentar.
* U02 � Crear grupo
* Actor principal: Usuario
Actor secundario: Firebase Firestore
* Precondici�n:
* El usuario debe haber iniciado sesi�n.
* El usuario debe encontrarse en la pantalla de inicio.
* Firebase Firestore debe estar disponible.
* Flujo principal:
* El usuario selecciona la opci�n Crear grupo.
* El sistema muestra el formulario de creaci�n.
* El usuario introduce el nombre del grupo.
* El usuario agrega los integrantes.
* El usuario confirma la creaci�n.
* El sistema valida la informaci�n.
* El sistema almacena el grupo en Firestore.
* El grupo aparece en la lista de grupos del usuario.
* Flujo de excepci�n:
* Si el nombre del grupo est� vac�o, el sistema solicita completarlo.
* Si no se agregan integrantes, el sistema informa que debe existir al menos un integrante.
* Si Firestore no est� disponible, el grupo no se crea y se informa al usuario.

* CU03 � Registrar gasto
* Actor principal: Usuario
Actor secundario: Firebase Firestore
* Precondici�n:
* El usuario debe haber iniciado sesi�n.
* El usuario debe pertenecer a un grupo.
* El grupo debe existir.
* El usuario debe encontrarse en la pantalla de registro de gasto.
* Firestore debe estar disponible.
* Flujo principal:
* El usuario selecciona el grupo.
* Introduce la descripci�n del gasto.
* Introduce el valor.
* Selecciona la moneda.
* Selecciona la fecha.
* Selecciona qui�n realiz� el pago.
* Selecciona los participantes.
* El sistema valida la informaci�n.
* El sistema calcula cu�nto corresponde a cada participante.
* El sistema almacena el gasto en Firestore.
* El sistema actualiza el historial.
* El sistema actualiza el balance de los integrantes.
* El sistema informa que el gasto fue registrado correctamente.
* Flujo de excepci�n:
* Si falta la descripci�n, el sistema solicita completarla.
* Si el valor es cero, negativo o inv�lido, el sistema solicita ingresar un valor v�lido.
* Si no se selecciona un pagador, el sistema solicita seleccionarlo.
* Si no se seleccionan participantes, el sistema solicita seleccionar al menos uno.
* Si ocurre un error al guardar en Firestore, el sistema informa que el gasto no pudo registrarse.

* CU04 � Consultar historial de gastos
* Actor principal: Usuario
Actor secundario: Firebase Firestore
* Precondici�n:
* El usuario debe haber iniciado sesi�n.
* El usuario debe pertenecer al grupo que desea consultar.
* El grupo debe existir.
* Deben existir o poder consultarse los registros de gastos.
* Flujo principal:
* El usuario selecciona un grupo.
* El sistema consulta los gastos asociados al grupo en Firestore.
* El sistema organiza los gastos por fecha.
* El sistema muestra el historial.
* El usuario puede consultar la informaci�n de cada gasto.
* Flujo de excepci�n:
* Si el grupo no tiene gastos registrados, el sistema muestra un mensaje indicando que no existen gastos en el historial.
* Si no se pueden obtener los datos de Firestore, el sistema informa que no fue posible cargar el historial.
* Si el usuario no pertenece al grupo, el sistema impide el acceso a la informaci�n.



* CU05 � Consultar balance
* Actor principal: Usuario
Actor secundario: Firebase Firestore
* Precondici�n:
* El usuario debe haber iniciado sesi�n.
* El usuario debe pertenecer a un grupo.
* El grupo debe tener acceso a sus registros de gastos.
* Flujo principal:
* El usuario selecciona un grupo.
* El sistema consulta los gastos hist�ricos.
* El sistema identifica los pagos realizados por cada integrante.
* El sistema calcula cu�nto corresponde aportar a cada participante.
* El sistema compara los aportes realizados con las obligaciones de cada integrante.
* El sistema calcula los balances.
* El sistema muestra cu�nto debe pagar o recibir cada usuario.
* Flujo de excepci�n:
* Si el grupo no tiene gastos registrados, el sistema muestra un balance de cero.
* Si existen datos incompletos en un gasto, el sistema excluye dicho registro del c�lculo y muestra una advertencia.
* Si no se pueden consultar los gastos, el sistema informa que no fue posible calcular el balance.
* 
* CU06 � Consultar tasa de cambio
* Actor principal: Usuario
Actor secundario: API de tasas de cambio
* Precondici�n:
* El usuario debe haber iniciado sesi�n.
* Debe existir un gasto registrado o un valor que se quiera convertir.
* El dispositivo debe tener conexi�n a Internet.
* La API de tasas de cambio debe estar disponible.
* Flujo principal:
* El usuario selecciona la opci�n de conversi�n.
* Selecciona la moneda de origen.
* Selecciona la moneda de destino.
* El sistema obtiene la tasa de cambio desde la API.
* La API devuelve la tasa correspondiente.
* El sistema calcula el valor convertido.
* El sistema muestra el resultado al usuario.
* Flujo de excepci�n:
* Si el usuario no selecciona una moneda de origen o destino, el sistema solicita completar la informaci�n.
* Si la API no est� disponible, el sistema informa que no fue posible obtener la tasa de cambio.
* Si no existe conexi�n a Internet, el sistema informa que se necesita conexi�n para realizar la consulta.
* Si la API no proporciona una tasa para las monedas seleccionadas, el sistema informa que la conversi�n no est� disponible.
* 
* CU07 � Consultar aportes hist�ricos
* Actor principal: Usuario
Actor secundario: Firebase Firestore
* Precondici�n:
* El usuario debe haber iniciado sesi�n.
* El usuario debe pertenecer al grupo.
* El grupo debe tener registros de gastos.
* Flujo principal:
* El usuario selecciona un grupo.
* El sistema consulta los gastos hist�ricos.
* El sistema identifica los pagos realizados por cada integrante.
* El sistema suma los aportes de cada usuario.
* El sistema muestra el total aportado por cada integrante.
* El usuario puede consultar la evoluci�n de sus aportes dentro del grupo.
* Flujo de excepci�n:
* Si no existen gastos registrados, el sistema muestra que no hay aportes hist�ricos.
* Si los datos no pueden ser consultados, el sistema informa que no fue posible cargar la informaci�n.
* Si existe informaci�n incompleta, el sistema muestra los datos disponibles y notifica la inconsistencia.
* 
* CU08 � Marcar deuda como saldada
* Actor principal: Usuario
Actor secundario: Firebase Firestore
* Precondici�n:
* El usuario debe haber iniciado sesi�n.
* Debe pertenecer al grupo.
* Debe existir una deuda registrada.
* El usuario debe tener permisos para modificar el estado de la deuda.
* Flujo principal:
* El usuario consulta el balance del grupo.
* Selecciona una deuda pendiente.
* Selecciona la opci�n Marcar como saldada.
* El sistema solicita confirmaci�n.
* El usuario confirma.
* El sistema actualiza el estado de la deuda en Firestore.
* El historial refleja que la deuda fue saldada.
* El balance se actualiza.
* Flujo de excepci�n:
* Si el usuario cancela la confirmaci�n, la deuda permanece pendiente.
* Si la deuda ya fue saldada, el sistema informa que no es necesario realizar ninguna acci�n.
* Si Firestore no permite actualizar la informaci�n, el sistema informa que no fue posible modificar el estado.
* 
* CU09 � Consultar informaci�n de un gasto
* Actor principal: Usuario
Actor secundario: Firebase Firestore
* Precondici�n:
* El usuario debe haber iniciado sesi�n.
* El usuario debe pertenecer al grupo.
* El gasto debe existir en el historial.
* Flujo principal:
* El usuario selecciona un gasto del historial.
* El sistema consulta la informaci�n almacenada.
* El sistema muestra la descripci�n, valor, moneda, fecha, pagador y participantes.
* El usuario consulta el detalle del gasto.
* Flujo de excepci�n:
* Si el gasto ya no existe, el sistema informa que el registro no est� disponible.
* Si no se puede consultar Firestore, el sistema informa que no fue posible cargar el detalle.
* Si el usuario no tiene permisos para consultar el gasto, el sistema bloquea el acceso.
Flujo general
* Inicio / Grupos
*        ?
*        ?????????????????
*        ?               ?
*        ?               ?
* Registrar gasto    Seleccionar grupo
*        ?               ?
*        ?               ?
*    Guardar       Historial y balance
*        ?               ?
*        ?????????????????
*                ?
*        Actualizar historial
*                ?
*                ?
*         Actualizar balance
Propuestas de diseno y mockups � dise�o en con Stich google
* Dise�o general
* La interfaz estar� enfocada en que el usuario pueda identificar r�pidamente:
* Cu�nto ha gastado.
* Cu�nto ha aportado.
* Cu�nto debe.
* Cu�nto debe recibir.
* Qu� gastos se han realizado anteriormente.
* Se utilizar�n colores diferenciados para facilitar la lectura:
* Verde: saldo a favor.
* Rojo: saldo pendiente.
* Gris: informaci�n secundaria.
* Blanco: contenido principal.
* Pantalla 1 � Inicio / Grupos
* ???????????????????????????
* ?  Mis grupos             ?
* ?                         ?
* ?  Apartamento            ?
* ?  Balance: +$80.000      ?
* ?                         ?
* ?  Viaje                   ?
* ?  Balance: -$35.000      ?
* ?                         ?
* ?  ?????????????????????  ?
* ?  ?   + Crear grupo   ?  ?
* ?  ?????????????????????  ?
* ???????????????????????????
* Pantalla 2 � Registrar gasto
* ???????????????????????????
* ?  Registrar gasto        ?
* ?                         ?
* ?  Descripci�n            ?
* ?  [ Mercado           ]  ?
* ?                         ?
* ?  Valor                  ?
* ?  [ $ 120.000         ]  ?
* ?                         ?
* ?  Moneda [ COP ? ]       ?
* ?  Fecha   [ 22/08/26 ]   ?
* ?                         ?
* ?  Pag�                   ?
* ?  [ Juan ?            ]  ?
* ?                         ?
* ?  Participantes          ?
* ?  ? Juan  ? Ana  ? Luis ?
* ?                         ?
* ?  [       GUARDAR      ] ?
* ???????????????????????????
* Pantalla 3 � Historial y balance
* ???????????????????????????
* ?  Apartamento            ?
* ?                         ?
* ?  Mi balance             ?
* ?  +$80.000               ?
* ?                         ?
* ?  Historial              ?
* ?                         ?
* ?  22 Ago  Mercado        ?
* ?           $240.000      ?
* ?                         ?
* ?  18 Ago  Servicios      ?
* ?           $180.000      ?
* ?                         ?
* ?  10 Ago  Limpieza       ?
* ?           $140.000      ?
* ?                         ?
* ?  Aportes                ?
* ?  Juan       $280.000    ?
* ?  Ana        $150.000    ?
* ?  Luis       $130.000    ?
* ???????????????????????????
* Gesti�n del proyecto en GitHub
* GitHub ser� el entorno central para desarrollar y documentar el proyecto.
* Issues
* Cada funcionalidad, tarea o error ser� registrado como una Issue.
* Ejemplos:
* #1 Configurar proyecto Flutter
* #2 Configurar Firebase Authentication
* #3 Configurar Firestore
* #4 Crear modelo de usuario
* #5 Crear modelo de grupo
* #6 Crear modelo de gasto
* #7 Crear pantalla de grupos
* #8 Crear pantalla de registro de gasto
* #9 Crear historial de gastos
* #10 Implementar c�lculo de balances
* #11 Integrar API de tasas de cambio
* #12 Implementar pruebas
* #13 Crear README
* #14 Revisar MVP
* Branches
* Cada funcionalidad se desarrollar� en una rama independiente:
* main
* ?
* ??? feature/auth
* ??? feature/grupos
* ??? feature/gastos
* ??? feature/historial
* ??? feature/balances
* ??? feature/api-monedas
* Pull Requests
* Cada funcionalidad terminada deber� integrarse mediante un Pull Request.
* El Pull Request deber�:
* Indicar la Issue relacionada.
* Explicar los cambios realizados.
* Incluir evidencia cuando sea necesario.
* Ser revisado por otro integrante.
* Mantener el proyecto funcional antes de integrarse a main.
* Organizaci�n del repositorio
* control-gastos-compartidos/
* ?
* ??? README.md
* ??? docs/
* ?   ??? especificaciones.md
* ?   ??? alcance.md
* ?   ??? mockups/
* ?
* ??? lib/
* ??? test/
* ??? pubspec.yaml
* ??? .gitignore
* README.md
* El README del repositorio deber� incluir:
* Nombre del proyecto.
* Descripci�n.
* Problema que aborda.
* Funcionalidades principales.
* Tecnolog�as utilizadas.
* API utilizada.
* Instrucciones para ejecutar el proyecto.
* Integrantes del equipo.
* Enlace a la documentaci�n.
* Estado actual del proyecto.
* De esta forma, el proyecto mantiene una trazabilidad completa desde el problema hasta el desarrollo: el problema define las necesidades, las historias de usuario representan esas necesidades, las Issues organizan el trabajo, las ramas contienen el desarrollo y los Pull Requests permiten revisar e integrar cada funcionalidad.
* 

Firebase / Base de datos:
* Firebase Authentication ? usuarios 
* Firestore ? grupos, integrantes y gastos 
* Firebase Storage ? opcional, para comprobantes/fotos 
API externa:
* Frankfurter ? tasas de cambio. 
Las 3 pantallas
1. ?? Resumen
* Mis grupos. 
* Total gastado. 
* Total que debo. 
* Total que me deben. 
* Moneda principal. 
2. ? Registrar gasto
* Descripci�n. 
* Valor. 
* Moneda. 
* Persona que pag�. 
* Personas que participan. 
* Fecha. 
* Guardar. 
3. ?? Detalle del grupo
* Gastos realizados. 
* Balance de cada integrante. 
* Deudas. 
* Conversi�n de monedas mediante la API. 
* Marcar deuda como pagada. 
?? �Por qu� esta combinaci�n est� buena?
Porque pueden demostrar en el proyecto:
Flutter + Dart + Git/GitHub + Firebase + Firestore + Authentication + API REST + Clean Architecture
Y cada tecnolog�a tiene una raz�n de existir:
             ????????????????
             ?    Flutter   ?
             ?   3 pantallas?
             ????????????????
                    ?
          ?????????????????????
          ? Clean Architecture?
          ????????????????????
                  ?     ?
          ??????????? ??????????????
          ? Firebase ? ? Frankfurter?
          ? Firestore? ?    API     ?
          ???????????? ??????????????

